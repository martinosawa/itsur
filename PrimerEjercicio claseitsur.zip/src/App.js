import logo from './logo.svg';
import './App.css';
import { PrimerComponente } from './components/PrimerComponente';
import { SegundoComponente } from './components/SegundoComponente';
import { TercerComponente } from './components/TercerComponente';
import { CuartoComponente } from './components/CuartoComponente';
import { MiEstado } from './components/MiEstado';
import { Ejercicio }  from './components/Ejercicio';
import { MiEfecto } from './components/MiEfecto';
import { AjaxComponent } from './components/AjaxComponent';
import { Formularios } from './components/Formularios';


function App() {
  const fichaMedica={
    altura:186,
    peso:90,
    tipodesangre:"a+",
    alergias:"abejas"
  }
  //var number=123;
  const Fecha = new Date ();
  const anio =Fecha.getFullYear();
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        {/*Este es el componente de estado
        <Ejercicio year={anio}></Ejercicio>
        <MiEfecto/>
        <AjaxComponent/>*/}
        <Formularios/>
      </header>
    </div>
  );
}

export default App;
