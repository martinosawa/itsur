import React, { useEffect, useState } from 'react'



export const AjaxComponent = () => {
    const [usuarios, setUsuarios] = useState([]);
    const [cargando, setCargando] = useState(true);
    const [errores, setErrores] = useState("");
    const getUsuariosEstaticos = () => {
        setUsuarios([{
            "id": 1, "email": "george.bluth@reqres.in",
            "first_name": "George", "last_name": "Bluth",
            "avatar": "https://reqres.in/img/faces/1-image.jpg"
        },
        {
            "id": 2, "email": "janet.weaver@reqres.in", "first_name": "Janet",
            "last_name": "Weaver",
            "avatar": "https://reqres.in/img/faces/2-image.jpg"
        },
        {
            "id": 3, "email": "emma.wong@reqres.in", "first_name": "Emma",
            "last_name": "Wong",
            "avatar": "https://reqres.in/img/faces/3-image.jpg"
        },
        {
            "id": 4, "email": "eve.holt@reqres.in", "first_name": "Eve",
            "last_name": "Holt",
            "avatar": "https://reqres.in/img/faces/4-image.jpg"
        },
        {
            "id": 5, "email": "charles.morris@reqres.in",
            "first_name": "Charles", "last_name": "Morris",
            "avatar": "https://reqres.in/img/faces/5-image.jpg"
        },
        {
            "id": 6, "email": "tracey.ramos@reqres.in", "first_name": "Tracey",
            "last_name": "Ramos",
            "avatar": "https://reqres.in/img/faces/6-image.jpg"
        }])
    }

    const getUsuariosAjaxPms = () => {
        fetch("https://reqres.in/api/users?page=2")
            .then(respuesta => respuesta.json())
            .then(resultadofinal => {
                setUsuarios(resultadofinal.data);
            }, error => { console.log(error.message) })
    }

    const getUsuariosAjaxAW = () => {

        setTimeout(async () => {
            try {
                const peticion = await fetch("https://reqres.MX/api/users?page=1");
                const { data } = await peticion.json();
                setUsuarios(data);
                setCargando(false);
            }
            catch (error) {
                setErrores(error.message);
                //setCargando(false);
            }
        }, 2000)

    

}

useEffect(() => {
    //getUsuariosEstaticos();
    //getUsuariosAjaxPms();
    getUsuariosAjaxAW();
}, [])

if (errores != "") {
    return (
        <div className='errores'>
            <p>Se encontro el siguiente error</p>
            <p>{errores}</p>
        </div>
    )
} else if (cargando == true) {
    return (
        <div className='cargando'>
            Loading...
        </div>
    )
} else if (cargando == false && errores === "") {
    return (
        <div>
            <h2>Listado de Usuarios via Ajax</h2>
            <ol className='usuarios'>
                {usuarios.map(usuario => {
                    console.log(usuario);
                    return (<li key={usuario.id}>
                        <img src={usuario.avatar} />
                        {usuario.first_name} {usuario.last_name}</li>)
                })}
            </ol>
        </div>
    )
}
}