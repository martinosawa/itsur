import React,{useEffect, useState} from 'react'
import { ComponenteAviso } from './ComponenteAviso';

export const MiEfecto = () => {
  const [usuario,setUsuario]=useState("Martin");
  const [contador,setContador]=useState(0);
  const [fecha,setFecha]=useState("28/07/2022");

  const cambiar=e=>{
    var nombretecleado= e.target.value; 
       setUsuario(nombretecleado);
    }

   const click=e=>{
    var date= new Date();
    setFecha(date.toLocaleTimeString());
   }

   useEffect(()=>{
    console.log("Se ha realizado un cambio");
    //setContador(contador+1);
   },[usuario])

   useEffect(()=>{
    console.log("Componente cargado");
   },[])

   useEffect(()=>{
    //setContador(contador+1);
    console.log("Has modificado la fecha");
   },[fecha,contador])

  return (
    <div>
    <h1>useEffect</h1>
    <p>{contador}</p>
    <p>Nombre de Usuario <strong className={contador>10?'label label-green':'label'}>{usuario}</strong></p>
    <button onClick={click}>Mostrar Fecha</button>
    <br/>
    <p>{fecha}</p>
    <input type="text" onChange={cambiar} placeholder='Intruduce un nuevo Usuario'/>
    <div className='aviso'>
    {usuario=="MARTIN"?<ComponenteAviso/>:"No eres bienvenido"}
    </div>
    </div>
  )
}
