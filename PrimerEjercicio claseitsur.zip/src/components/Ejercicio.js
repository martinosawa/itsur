import React, {useState} from 'react'
import PropTypes from 'prop-types'

export const Ejercicio = ({year}) => {
  const[yearNow,setYearNow]=useState(year);

  const before=e=>{
      let res=yearNow-1;
      setYearNow(res);
  }

  const next =e=>{
      setYearNow(yearNow+1);
  }

  const teclear=e=>{
      let val=parseInt(e.target.value);
    if(Number.isInteger(val)){
      setYearNow(val);
    }else
    {
        alert("No es un tipo valido");
    }
  }
    
  return (
    <div>
    <h1>Ejercicio</h1>
    <p>El año actual es {yearNow}</p>
    <button onClick={before}>Anterior</button>
    <button onClick={next}>Siguiente</button>
    <p>Introducrir Año Manualmente</p>
    <input type="number" onChange={teclear} placeholder='2022'></input>
    </div>
  )
}

Ejercicio.propTypes={
year:PropTypes.number.isRequired
}
