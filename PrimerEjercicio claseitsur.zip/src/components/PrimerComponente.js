import React from 'react'

export const PrimerComponente = () => {
 const nombre="Martin";
 let apellido="Herrera";
 let usuario={
     nombre:"Martin",
     apellido:"Herrera",
     estatura:160
 }
    let altura="Promedio"   
    if(usuario.estatura>=180){
    altura="Alto";
    }else if(usuario.estatura<=150){
    altura="Chaparrito";
    }

  return (
    <div className='primercomponente'>
    <h1>Primer Componente en React</h1>
    <ul>
    <li>Mi nombre es <strong>{nombre}</strong></li>
    <li>Mi apellido es <strong>{apellido}</strong></li>    
    </ul>
    <ol>
    <li>Nombre de usuario: {usuario.nombre}</li>
    <li>Apellido de usuario: {usuario.apellido}</li>
    <li>Estatura de usuario: {usuario.estatura}</li>
    <li>El usuario es {altura}</li>
    </ol>
    </div>
    
  )
}
