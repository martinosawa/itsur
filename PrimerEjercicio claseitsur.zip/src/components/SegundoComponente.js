import React from 'react'

export const SegundoComponente = () => {
  //const libros =["El Psicoanalista","El libro vaquero","Persuacion","Condorito"];
  const libros=[];
  return (
    <div className='SegundoComponente'>
        <h2>Segundo Componente</h2>
        <h1>Listado de Libros</h1>
        {libros.length>=1?(
        <ul>
         {libros.map((libro,indice)=>{
           return <li key={indice}>{libro}</li> 
          })} 
        
        </ul>
        ):
        (<p>No hay libros</p>)
        }
    </div>
  )
}
