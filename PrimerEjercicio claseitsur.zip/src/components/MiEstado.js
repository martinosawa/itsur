import React,{useState} from 'react'

export const MiEstado = () => {
    /*let nombre="Martin";
    const click=e=>{
        nombre="Adolfo";
    }*/
    const[nombre,setNombre]=useState("Adolfo");
    const[contador,setContador]=useState(0);

    const click=e=>{
        setNombre("Herrera");
    }

    const tecla=e=>{
     var nombretecleado= e.target.value; 
        setNombre(nombretecleado);
    }

    const click2=e=>{
        setContador(contador+1);
    }

  return (
    <div>
        <h1>Hook useState</h1>
        <p>Mi nombre es <strong>{nombre}</strong></p>
        <button onClick={click}>Cambiar Nombre</button>
        <input type="text" onChange={tecla} placeholder='Intruduce un nuevo Nombre'/>
        <p>Has clikeado <strong>{contador}</strong></p>
        <button onClick={click2}>Contador</button>
    </div>
  )
}
