import React from 'react'
import PropTypes from "prop-types"

export const TercerComponente = ({apellido="Perez",nombre="juan",ficha}) => {
  //console.log(props);  
  return (
    <div>
        <h1>Comunicacion entre componentes</h1>
        <ul>
            <li>Nombre: {nombre}</li>
            <li>Apellido:{apellido}</li>
            <li>Altura: {ficha.altura}</li>
            <li>Peso: {ficha.peso}</li>
            <li>Tipo de sangre: {ficha.tipodesangre}</li>
            <li>Alergias: {ficha.alergias}</li>
        </ul>
    </div>
  )
}

TercerComponente.propTypes={
nombre:PropTypes.string,
apellido:PropTypes.string.isRequired,
ficha:PropTypes.shape({
    altura:PropTypes.number,
    peso:PropTypes.number,
    tipodesangre:PropTypes.string,
    alergias:PropTypes.string
}),   
}

TercerComponente.defaultProps={
    nombre:"Chabelo",
    apellido:"Lopez",
    ficha:{
        altura:170,
        peso:60,
        tipodesangre:"O+",
        alergias:"la tarea"
    }
}