import React , {useState} from 'react'

export const Formularios = () => {

    const [usuario,setUsuario]=useState([]);
    const conseguirDatos=e=>{
        e.preventDefault();
        const datos = e.target;
        //console.log(datos);
        let usuario ={
            nombre:datos.nombre.value,
            apellido:datos.apellido.value,
            genero:datos.genero.value,
            bio:datos.bio.value
        };
        console.log(usuario);
        setUsuario(usuario);

    }
    const cambiarDatos =e=>{
        let nombreDelInput=e.target.name;
        setUsuario(estadoPrevio =>{
        return{
            ...estadoPrevio,
            [nombreDelInput]:e.target.value
        }})
    }
  return (
    <div>
    <h1>Formularios con React</h1>
    
    <div className='info'>
    {usuario.nombre} {usuario.apellido} es {usuario.genero} y su bio es {usuario.bio}    
    </div>
    <form onSubmit={conseguirDatos}>
    <input onChange={cambiarDatos} name="nombre" type="text" placeholder='Nombre'/>
    <input onChange={cambiarDatos} name="apellido" type="text" placeholder='Apellido'/>
    <select onChange={cambiarDatos} name="genero">
        <option>Hombre</option>
        <option>Mujer</option>
        <option>No Binario</option>
    </select>
    <textarea onChange={cambiarDatos} name="bio" placeholder="Bio"/>
    <input type="submit" value="enviar" className='submit'></input>
        
    </form>    
    </div>
  )
}
