import React, { useEffect } from 'react'

export const ComponenteAviso = () => {

   useEffect(()=>{
    console.log("El componente aviso se ha cargado");
    return(()=>{
        console.log("El componente aviso ha sido desmontado");
    })
   },[]) 

  return (
    <div>
        <h3>Este es el componente de aviso</h3>
        <button onClick={e=>{alert("Que onda")}}>Saludo</button>
    </div>
  )
}
