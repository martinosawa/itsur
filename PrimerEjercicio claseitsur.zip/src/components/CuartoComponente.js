import React from 'react'

export const CuartoComponente = () => {
  let nombre="Sandra";

    function unClick(){
    //alert("diste un Click");
    nombre="Juana";
  }

  const dobleClick= ()=>{
alert("diste Doble Click");
  }

  const entrar=()=>{
      //alert("entraste");
      console.log("Entrar");
  }

  const salir=()=>{
    //alert ("saliste");
    console.log("Salir");
    }

    const foco=()=>{
    console.log("Focus In");    
    }

    const blured=()=>{
        console.log("Focus Lost");    
        }

    const evento=(e)=>{
        console.log(e);
        console.log(e.target.value);
    }

    return (
    <div>
    <h1>Eventos en React</h1>
    <button onClick={unClick}>Click</button>
    &nbsp;
    <button onDoubleClick={dobleClick}>DobleClick</button>
    <br/>
    <div id='area'
            onMouseEnter={entrar}
            onMouseLeave={salir}
    >
    Area 51    
    </div>
    &nbsp;
    <p>
    <input type="text" 
    onFocus={foco}
    onBlur={blured}
    onChange={evento} 
    placeholder="Eventos"
    />
    </p>
    <p>
        <strong>{nombre}</strong>
    </p>    
    </div>
  )
}
