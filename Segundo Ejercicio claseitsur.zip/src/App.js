import './App.css';
import { Listado } from './componentes/Listado';
import { Buscador } from './componentes/Buscador';
import { Agregar } from './componentes/Agregar';
import { useState,useEffect } from 'react'

function App() {
  const [listadoState, setListadoState] = useState([]);
  useEffect(() => {
    conseguirPeliculas();
    console.log("Componente cargado")
}, []);
const conseguirPeliculas = () => {
    let movies = JSON.parse(localStorage.getItem("Movies"));
    console.log(movies);
    setListadoState(movies);
    return movies;
}
  return (
    <div className="App">
       <div className="layout">
        {/*Cabecera*/}
        <header className="header">
            <div className="logo">
                <div className="play"></div>
            </div>
            
            <h1>X Movies</h1>
        </header>

        {/*Barra de navegación*/}
        <nav className="nav">
            <ul>
                <li><a href="/#">Inicio</a></li>
                <li><a href="/#">Peliculas</a></li>
                <li><a href="/#">Blog</a></li>
                <li><a href="/#">Contacto</a></li>
            </ul>
        </nav>

        {/*Contenido principal*/}
        <Listado listadoState={listadoState}
                setListadoState={setListadoState}
                                />

        {/*Barra lateral*/}
        <aside className="lateral">
        <Buscador
            listadoState={listadoState}
            setListadoState={setListadoState}
            />
        <Agregar 
                setListadoState={setListadoState}
              />



        </aside>

        {/*Pie de página*/}
        <footer className="footer">
            &copy; Primer Proyecto - <a href="www.algo.com">Martin Adolfo 2022 Todos los derechos reservados</a>
        </footer>

    </div>
    </div>
  );
}

export default App;
