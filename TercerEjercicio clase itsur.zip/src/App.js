
import { useState } from 'react';
import './App.css';
import { AppContext, AppProvider } from './Contexto/AppProvider';
import { FuncionContexto } from './Contexto/FuncionContexto';
import { NumeroContexto } from './Contexto/NumeroContexto';
import { UsuarioContexto } from './Contexto/UsuarioContexto';
import { RouterPrincipal } from './rutas/RouterPrincipal';

function App() {
  const [usuario,setUsuario]=useState({
    nick:"Batman",
    nombre:"Bruce",
    apellido:"Wayne"
  })

  const funcion = ()=>{
    alert("Funcion mandada por contexto");
  }
  return (
    <>{/*<FuncionContexto.Provider value={funcion}>
    <NumeroContexto.Provider value={96}>
  <UsuarioContexto.Provider value={{usuario,setUsuario}}>*/}
    <AppProvider>
    <RouterPrincipal/>
    </AppProvider>
    {/*</UsuarioContexto.Provider>
    </NumeroContexto.Provider>
    </FuncionContexto.Provider>*/}
    </>
  );
}

export default App;
