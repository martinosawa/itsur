import React from 'react'
import {Routes,Route,Link,BrowserRouter, NavLink, Navigate} from 'react-router-dom';
import { Acercade } from '../componentes/Acercade';
import { Articulos } from '../componentes/Articulos';
import { Contacto } from '../componentes/Contacto';
import { Inicio } from '../componentes/Inicio';
import { Error } from '../componentes/Error';
import { Persona } from '../componentes/Persona';
import { PanelControl } from '../componentes/PanelControl';
import { Gestion } from '../componentes/panel/Gestion';
import { AgregarArticulo } from '../componentes/panel/AgregarArticulo';
import { InicioPanel } from '../componentes/panel/Inicio';
import { Login } from '../componentes/Login';

export const RouterPrincipal = () => {
  return (
    <BrowserRouter>
    <header className='header'>
    <nav>
    <ul>
        <li><NavLink className={({isActive})=>isActive?"activado":""}to="/inicio">Inicio</NavLink></li>
        <li><NavLink className={({isActive})=>isActive?"activado":""}to='/acercade'>Acerca de</NavLink></li>
        <li><NavLink className={({isActive})=>isActive?"activado":""}to='/contacto'>Contacto</NavLink></li>
        <li><NavLink className={({isActive})=>isActive?"activado":""}to='/articulos'>Articulos</NavLink></li>
        <li><NavLink className={({isActive})=>isActive?"activado":""}to='/panel'>Panel de Control</NavLink></li>
        <li><NavLink className={({isActive})=>isActive?"activado":""}to='/login'>Iniciar Sesion</NavLink></li>
    </ul>    
    </nav>    
    </header>
    <section className='content'>
        <Routes>
            <Route path="/login" element={<Login/>}/>
            <Route path="/" element={<Inicio/>}/>
            <Route path="/inicio" element={<Inicio/>}/>
            <Route path="/articulos" element={<Articulos/>}/>
            <Route path="/contacto" element={<Contacto/>}/>
            <Route path="/acercade" element={<Acercade/>}/>
            <Route path="/panel/*" element={<PanelControl/>}>
                <Route path="inicio/" element={<InicioPanel/>}/>
                <Route index element={<InicioPanel/>}/>
                <Route path="gestion/" element={<Gestion/>}/>
                <Route path="agregararticulo/" element={<AgregarArticulo/>}/>
                <Route path="*" element={<h1>Error</h1>}/>
            </Route>
            <Route path="/*" element={<Error/>}/>
            <Route path="/persona/:nombre/:apellido" element={<Persona/>}/>
            <Route path="/persona/:nombre" element={<Persona/>}/>
            <Route path="/persona" element={<Persona/>}/>
            <Route path="/redirigir" element={<Navigate to="/persona/Usuario/Defecto"/>}/>
        </Routes>
    </section>
    </BrowserRouter>
  )
}
