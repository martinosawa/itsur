import React from 'react'

export const Inicio = () => {
  return (
    <div>Inicio</div>
  )
}
