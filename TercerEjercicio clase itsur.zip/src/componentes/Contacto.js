import React from 'react'

export const Contacto = () => {
  return (
    <div>Contacto</div>
  )
}
