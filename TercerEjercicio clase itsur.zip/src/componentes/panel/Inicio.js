import React from 'react'

export const InicioPanel = () => {
  return (
    <div>
     <h1>Ojo este es el inicio del panel de control</h1>   
    </div>
  )
}
