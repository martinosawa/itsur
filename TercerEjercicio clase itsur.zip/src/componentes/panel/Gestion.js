import React, { useContext } from 'react'
import { AppContext } from '../../Contexto/AppProvider';


export const Gestion = () => {
  const {funcion} = useContext(AppContext);
  funcion();
  return (
    <div>Gestion</div>
  )
}
