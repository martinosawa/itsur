import React from 'react'

export const AgregarArticulo = () => {
  return (
    <div>AgregarArticulo</div>
  )
}
