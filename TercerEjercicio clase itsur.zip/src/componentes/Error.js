import React from 'react'
import { Link} from 'react-router-dom'

export const Error = () => {
  return (
    <div>
        <h1>ERROR 404</h1>
        <p>Ruta no reconocida</p>
        <a href='/inicio'>Volver al Inicio con un link convencional</a>
        <hr/>
        <Link to="/inicio">Vuelve al inicio con React Router</Link>
    </div>
  )
}
