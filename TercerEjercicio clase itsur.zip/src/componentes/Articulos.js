import React, { useContext } from 'react'
import { AppContext } from '../Contexto/AppProvider';

export const Articulos = () => {
  const {numero}=useContext(AppContext);
  return (
    <div>Articulos en bodega:{numero}</div>
  )
}
