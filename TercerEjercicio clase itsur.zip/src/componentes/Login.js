import React, { useContext } from 'react'
import { AppContext } from '../Contexto/AppProvider';
import { UsuarioContexto } from '../Contexto/UsuarioContexto'

export const Login = () => {
    const {usuario,setUsuario}=useContext(AppContext);
    console.log(usuario);
    const iniciarSesion=(e)=>{
        e.preventDefault();
        let usuarioLogin ={
            nick:e.target.nick.value,
            nombre:e.target.nombre.value,
            apellido:e.target.apellido.value
        }
        setUsuario(usuarioLogin);
    }
  return (
    <div>
    <h1>Bienvenido:{usuario.nick} {usuario.nombre} {usuario.apellido}</h1>
    <form onSubmit={iniciarSesion}>
     <input type="text" placeholder='Nickname'name="nick"/>
     <input type="text"placeholder='Nombre'name="nombre"/>
     <input type="text"placeholder='Apellido'name="apellido"/> 
     <input type="submit" value= "Iniciar Sesion"/>    
    </form>
    </div>
  )
}
