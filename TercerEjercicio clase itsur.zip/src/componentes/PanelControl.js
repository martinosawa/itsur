import React from 'react'
import {NavLink, Outlet} from 'react-router-dom';

export const PanelControl = () => {
  return (
    <div>
    <nav>
    <ul>
        <li><NavLink className={({isActive})=>isActive?"activado":""}to="inicio">Inicio</NavLink></li>
        <li><NavLink className={({isActive})=>isActive?"activado":""}to='gestion'>Gestion</NavLink></li>
        <li><NavLink className={({isActive})=>isActive?"activado":""}to='agregararticulo'>Agregar Articulo</NavLink></li>
    </ul>    
    </nav>
    <div>
        {/*Quiero que carguen las subrutas */}
        <Outlet/>
    </div>    
    </div>
  )
}
