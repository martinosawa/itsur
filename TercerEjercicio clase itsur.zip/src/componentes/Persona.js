import React from 'react'
import { useNavigate, useParams } from 'react-router-dom'

export const Persona = () => {
  const {nombre,apellido}=useParams();
  const navegar=useNavigate();

  const enviar =(e)=>{
        e.preventDefault();
        let nombre=e.target.nombre.value;
        let apellido=e.target.apellido.value;
        let url=`/persona/${nombre}/${apellido}`;
        navegar(url);
  }
    
  return (
    <div>
        {!nombre&&<h1>No hay ningun usuario online</h1>}
        {nombre&&<h1>Bienvenido {nombre} {apellido}</h1>}
        <form onSubmit={enviar}>
         <input type="text" placeholder='Nombre' name="nombre"/>
         <input type="text" placeholder='Apellido' name="apellido"/>
         <input type="submit" value="Navegar"/>     
        </form>
    </div>
  )
}
