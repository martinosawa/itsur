import React from 'react'

export const Acercade = () => {
  return (
    <div>Acercade</div>
  )
}
