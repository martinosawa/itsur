import { createContext } from "react";
export const FuncionContexto =createContext();
