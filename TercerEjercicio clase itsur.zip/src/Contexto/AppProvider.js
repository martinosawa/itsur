import React, { createContext,useState } from 'react'
export const AppContext =createContext();
export const AppProvider = ({children}) => {
    const [usuario,setUsuario]=useState({
        nick:"Batman",
        nombre:"Bruce",
        apellido:"Wayne"
      })

  return (
    <AppContext.Provider value={{
        usuario,
        setUsuario,
        numero:69,
        funcion: ()=>{
            alert("Funcion mandada por contexto");
          }
        }}
     >
     {children}   
    </AppContext.Provider>
  )
}
