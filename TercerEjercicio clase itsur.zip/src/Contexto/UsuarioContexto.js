import { createContext } from "react";

export const UsuarioContexto=createContext();

